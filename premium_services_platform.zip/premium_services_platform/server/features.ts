/**
 * Feature routers for services, offers, reviews, and orders
 * Handles all business logic for the platform
 */

import { z } from 'zod';
import { publicProcedure, protectedProcedure, router } from './_core/trpc';
import { getDb } from './db';
import { services, offers, reviews, orders, type InsertService, type InsertOffer, type InsertReview, type InsertOrder } from '../drizzle/schema';
import { eq } from 'drizzle-orm';
import { TRPCError } from '@trpc/server';

/**
 * Services Router
 */
export const servicesRouter = router({
  // Get all active services
  list: publicProcedure.query(async () => {
    const db = await getDb();
    if (!db) return [];
    try {
      return await db.select().from(services).where(eq(services.isActive, 1));
    } catch (error) {
      console.error('Error fetching services:', error);
      return [];
    }
  }),

  // Create service (admin only)
  create: protectedProcedure
    .input(
      z.object({
        nameEn: z.string().min(1),
        nameAr: z.string().min(1),
        descriptionEn: z.string().optional(),
        descriptionAr: z.string().optional(),
        icon: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      if (ctx.user?.role !== 'admin') {
        throw new TRPCError({ code: 'FORBIDDEN' });
      }

      const db = await getDb();
      if (!db) throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR' });

      try {
        const result = await db.insert(services).values(input);
        return { success: true, id: result[0] };
      } catch (error) {
        console.error('Error creating service:', error);
        throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR' });
      }
    }),

  // Update service (admin only)
  update: protectedProcedure
    .input(
      z.object({
        id: z.number(),
        nameEn: z.string().optional(),
        nameAr: z.string().optional(),
        descriptionEn: z.string().optional(),
        descriptionAr: z.string().optional(),
        isActive: z.number().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      if (ctx.user?.role !== 'admin') {
        throw new TRPCError({ code: 'FORBIDDEN' });
      }

      const db = await getDb();
      if (!db) throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR' });

      try {
        const { id, ...updateData } = input;
        await db.update(services).set(updateData).where(eq(services.id, id));
        return { success: true };
      } catch (error) {
        console.error('Error updating service:', error);
        throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR' });
      }
    }),

  // Delete service (admin only)
  delete: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      if (ctx.user?.role !== 'admin') {
        throw new TRPCError({ code: 'FORBIDDEN' });
      }

      const db = await getDb();
      if (!db) throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR' });

      try {
        await db.delete(services).where(eq(services.id, input.id));
        return { success: true };
      } catch (error) {
        console.error('Error deleting service:', error);
        throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR' });
      }
    }),
});

/**
 * Offers Router
 */
export const offersRouter = router({
  // Get all active offers
  list: publicProcedure.query(async () => {
    const db = await getDb();
    if (!db) return [];
    try {
      return await db.select().from(offers).where(eq(offers.isActive, 1));
    } catch (error) {
      console.error('Error fetching offers:', error);
      return [];
    }
  }),

  // Create offer (admin only)
  create: protectedProcedure
    .input(
      z.object({
        titleEn: z.string().min(1),
        titleAr: z.string().min(1),
        descriptionEn: z.string().optional(),
        descriptionAr: z.string().optional(),
        discount: z.number().optional(),
        imageUrl: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      if (ctx.user?.role !== 'admin') {
        throw new TRPCError({ code: 'FORBIDDEN' });
      }

      const db = await getDb();
      if (!db) throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR' });

      try {
        const result = await db.insert(offers).values(input);
        return { success: true, id: result[0] };
      } catch (error) {
        console.error('Error creating offer:', error);
        throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR' });
      }
    }),

  // Delete offer (admin only)
  delete: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      if (ctx.user?.role !== 'admin') {
        throw new TRPCError({ code: 'FORBIDDEN' });
      }

      const db = await getDb();
      if (!db) throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR' });

      try {
        await db.delete(offers).where(eq(offers.id, input.id));
        return { success: true };
      } catch (error) {
        console.error('Error deleting offer:', error);
        throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR' });
      }
    }),
});

/**
 * Reviews Router
 */
export const reviewsRouter = router({
  // Get all approved reviews
  list: publicProcedure.query(async () => {
    const db = await getDb();
    if (!db) return [];
    try {
      return await db.select().from(reviews).where(eq(reviews.isApproved, 1));
    } catch (error) {
      console.error('Error fetching reviews:', error);
      return [];
    }
  }),

  // Get all reviews (admin only)
  listAll: protectedProcedure.query(async ({ ctx }) => {
    if (ctx.user?.role !== 'admin') {
      throw new TRPCError({ code: 'FORBIDDEN' });
    }

    const db = await getDb();
    if (!db) return [];
    try {
      return await db.select().from(reviews);
    } catch (error) {
      console.error('Error fetching all reviews:', error);
      return [];
    }
  }),

  // Create review (public)
  create: publicProcedure
    .input(
      z.object({
        customerName: z.string().min(1),
        rating: z.number().min(1).max(5),
        commentEn: z.string().optional(),
        commentAr: z.string().optional(),
        imageUrl: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR' });

      try {
        const result = await db.insert(reviews).values({
          ...input,
          isApproved: 0,
        });
        return { success: true, id: result[0] };
      } catch (error) {
        console.error('Error creating review:', error);
        throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR' });
      }
    }),

  // Approve review (admin only)
  approve: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      if (ctx.user?.role !== 'admin') {
        throw new TRPCError({ code: 'FORBIDDEN' });
      }

      const db = await getDb();
      if (!db) throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR' });

      try {
        await db.update(reviews).set({ isApproved: 1 }).where(eq(reviews.id, input.id));
        return { success: true };
      } catch (error) {
        console.error('Error approving review:', error);
        throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR' });
      }
    }),

  // Delete review (admin only)
  delete: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      if (ctx.user?.role !== 'admin') {
        throw new TRPCError({ code: 'FORBIDDEN' });
      }

      const db = await getDb();
      if (!db) throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR' });

      try {
        await db.delete(reviews).where(eq(reviews.id, input.id));
        return { success: true };
      } catch (error) {
        console.error('Error deleting review:', error);
        throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR' });
      }
    }),
});

/**
 * Orders Router
 */
export const ordersRouter = router({
  // Create order (public)
  create: publicProcedure
    .input(
      z.object({
        serviceId: z.number(),
        platform: z.string().min(1),
        amount: z.string().min(1),
        currency: z.string().min(1),
        accountId: z.string().min(1),
        customerName: z.string().min(1),
        phoneNumber: z.string().min(1),
        notes: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR' });

      try {
        const result = await db.insert(orders).values({
          ...input,
          status: 'pending',
        });
        return { success: true, id: result[0] };
      } catch (error) {
        console.error('Error creating order:', error);
        throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR' });
      }
    }),

  // Get all orders (admin only)
  list: protectedProcedure.query(async ({ ctx }) => {
    if (ctx.user?.role !== 'admin') {
      throw new TRPCError({ code: 'FORBIDDEN' });
    }

    const db = await getDb();
    if (!db) return [];
    try {
      return await db.select().from(orders);
    } catch (error) {
      console.error('Error fetching orders:', error);
      return [];
    }
  }),
});
