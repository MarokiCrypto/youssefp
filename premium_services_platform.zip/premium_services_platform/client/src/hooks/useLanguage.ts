import { useEffect, useState } from 'react';
import { getCurrentLanguage, setLanguage, t, type Language } from '@/lib/i18n';

/**
 * Hook for managing language and translations
 * Provides current language, translation function, and language setter
 */
export function useLanguage() {
  const [language, setLanguageState] = useState<Language>('en');
  const [isRTL, setIsRTL] = useState(false);

  useEffect(() => {
    // Initialize language from localStorage
    const currentLanguage = getCurrentLanguage();
    setLanguageState(currentLanguage);
    setIsRTL(currentLanguage === 'ar');
  }, []);

  const changeLanguage = (newLanguage: Language) => {
    setLanguage(newLanguage);
    setLanguageState(newLanguage);
    setIsRTL(newLanguage === 'ar');
  };

  const translate = (key: string): string => {
    return t(key, language);
  };

  return {
    language,
    changeLanguage,
    t: translate,
    isRTL,
    dir: isRTL ? 'rtl' : 'ltr',
  };
}
