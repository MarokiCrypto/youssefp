import { trpc } from '@/lib/trpc';

/**
 * Hook for fetching services from the server
 */
export function useServices() {
  const { data: services = [], isLoading, error } = trpc.services.list.useQuery();
  return { services, isLoading, error };
}

/**
 * Hook for fetching offers from the server
 */
export function useOffers() {
  const { data: offers = [], isLoading, error } = trpc.offers.list.useQuery();
  return { offers, isLoading, error };
}

/**
 * Hook for fetching approved reviews from the server
 */
export function useReviews() {
  const { data: reviews = [], isLoading, error } = trpc.reviews.list.useQuery();
  return { reviews, isLoading, error };
}

/**
 * Hook for creating an order
 */
export function useCreateOrder() {
  const mutation = trpc.orders.create.useMutation();
  return mutation;
}
