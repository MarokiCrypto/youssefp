/**
 * Internationalization (i18n) Configuration
 * Supports Arabic (RTL) and English (LTR)
 */

export type Language = 'en' | 'ar';

export const LANGUAGES = {
  en: { name: 'English', dir: 'ltr' },
  ar: { name: 'العربية', dir: 'rtl' },
} as const;

// Translation keys and values
export const translations = {
  en: {
    // Navigation
    nav: {
      home: 'Home',
      services: 'Services',
      about: 'About Us',
      faq: 'FAQ',
      contact: 'Contact Us',
      terms: 'Terms & Conditions',
      privacy: 'Privacy Policy',
    },
    // Common
    common: {
      language: 'Language',
      theme: 'Theme',
      lightMode: 'Light',
      darkMode: 'Dark',
      loading: 'Loading...',
      error: 'Error',
      success: 'Success',
      submit: 'Submit',
      cancel: 'Cancel',
      delete: 'Delete',
      edit: 'Edit',
      add: 'Add',
      save: 'Save',
      close: 'Close',
      back: 'Back',
      next: 'Next',
      previous: 'Previous',
    },
    // Home Page
    home: {
      title: 'Premium Digital Services',
      subtitle: 'Fast, Secure, and Professional',
      hero: 'Your trusted partner for digital services',
      cta: 'Get Started',
      featuredServices: 'Featured Services',
      offers: 'Special Offers',
      testimonials: 'Customer Reviews',
    },
    // Services
    services: {
      title: 'Our Services',
      description: 'Choose from our wide range of digital services',
      selectService: 'Select a Service',
      usdtRecharge: 'USDT Recharge',
      bettingSites: 'Betting Sites',
      games: 'Games',
      other: 'Other Services',
    },
    // Order Form
    form: {
      title: 'Place Your Order',
      service: 'Service',
      platform: 'Platform / Game',
      amount: 'Amount',
      currency: 'Currency',
      accountId: 'Account ID / Username',
      customerName: 'Your Name',
      phoneNumber: 'Phone Number',
      notes: 'Additional Notes',
      submit: 'Send via WhatsApp',
      required: 'This field is required',
      invalidPhone: 'Please enter a valid phone number',
      success: 'Order submitted successfully!',
      error: 'Failed to submit order. Please try again.',
    },
    // About
    about: {
      title: 'About Us',
      description: 'We are a leading provider of digital services...',
    },
    // FAQ
    faq: {
      title: 'Frequently Asked Questions',
      description: 'Find answers to common questions',
    },
    // Contact
    contact: {
      title: 'Contact Us',
      description: 'Get in touch with our team',
      email: 'Email',
      phone: 'Phone',
      message: 'Message',
      send: 'Send Message',
    },
    // Footer
    footer: {
      copyright: '© 2026 Premium Services. All rights reserved.',
      followUs: 'Follow Us',
      quickLinks: 'Quick Links',
    },
    // Admin
    admin: {
      title: 'Admin Dashboard',
      services: 'Services Management',
      offers: 'Offers Management',
      reviews: 'Reviews Management',
      orders: 'Orders',
      addService: 'Add Service',
      editService: 'Edit Service',
      deleteService: 'Delete Service',
      addOffer: 'Add Offer',
      editOffer: 'Edit Offer',
      deleteOffer: 'Delete Offer',
      addReview: 'Add Review',
      editReview: 'Edit Review',
      deleteReview: 'Delete Review',
      approve: 'Approve',
      reject: 'Reject',
    },
  },
  ar: {
    // Navigation
    nav: {
      home: 'الرئيسية',
      services: 'الخدمات',
      about: 'من نحن',
      faq: 'الأسئلة الشائعة',
      contact: 'اتصل بنا',
      terms: 'الشروط والأحكام',
      privacy: 'سياسة الخصوصية',
    },
    // Common
    common: {
      language: 'اللغة',
      theme: 'المظهر',
      lightMode: 'فاتح',
      darkMode: 'داكن',
      loading: 'جاري التحميل...',
      error: 'خطأ',
      success: 'نجح',
      submit: 'إرسال',
      cancel: 'إلغاء',
      delete: 'حذف',
      edit: 'تعديل',
      add: 'إضافة',
      save: 'حفظ',
      close: 'إغلاق',
      back: 'رجوع',
      next: 'التالي',
      previous: 'السابق',
    },
    // Home Page
    home: {
      title: 'خدمات رقمية فاخرة',
      subtitle: 'سريعة وآمنة واحترافية',
      hero: 'شريكك الموثوق في الخدمات الرقمية',
      cta: 'ابدأ الآن',
      featuredServices: 'الخدمات المميزة',
      offers: 'العروض الخاصة',
      testimonials: 'تقييمات العملاء',
    },
    // Services
    services: {
      title: 'خدماتنا',
      description: 'اختر من مجموعة واسعة من الخدمات الرقمية',
      selectService: 'اختر خدمة',
      usdtRecharge: 'شحن USDT',
      bettingSites: 'مواقع المراهنات',
      games: 'الألعاب',
      other: 'خدمات أخرى',
    },
    // Order Form
    form: {
      title: 'تقديم طلب',
      service: 'الخدمة',
      platform: 'المنصة / اللعبة',
      amount: 'المبلغ',
      currency: 'العملة',
      accountId: 'معرف الحساب / اسم المستخدم',
      customerName: 'اسمك',
      phoneNumber: 'رقم الهاتف',
      notes: 'ملاحظات إضافية',
      submit: 'إرسال عبر واتساب',
      required: 'هذا الحقل مطلوب',
      invalidPhone: 'يرجى إدخال رقم هاتف صحيح',
      success: 'تم تقديم الطلب بنجاح!',
      error: 'فشل تقديم الطلب. يرجى المحاولة مرة أخرى.',
    },
    // About
    about: {
      title: 'من نحن',
      description: 'نحن مزود خدمات رقمية رائد...',
    },
    // FAQ
    faq: {
      title: 'الأسئلة الشائعة',
      description: 'ابحث عن إجابات للأسئلة الشائعة',
    },
    // Contact
    contact: {
      title: 'اتصل بنا',
      description: 'تواصل مع فريقنا',
      email: 'البريد الإلكتروني',
      phone: 'الهاتف',
      message: 'الرسالة',
      send: 'إرسال الرسالة',
    },
    // Footer
    footer: {
      copyright: '© 2026 الخدمات الفاخرة. جميع الحقوق محفوظة.',
      followUs: 'تابعنا',
      quickLinks: 'روابط سريعة',
    },
    // Admin
    admin: {
      title: 'لوحة التحكم',
      services: 'إدارة الخدمات',
      offers: 'إدارة العروض',
      reviews: 'إدارة التقييمات',
      orders: 'الطلبات',
      addService: 'إضافة خدمة',
      editService: 'تعديل خدمة',
      deleteService: 'حذف خدمة',
      addOffer: 'إضافة عرض',
      editOffer: 'تعديل عرض',
      deleteOffer: 'حذف عرض',
      addReview: 'إضافة تقييم',
      editReview: 'تعديل تقييم',
      deleteReview: 'حذف تقييم',
      approve: 'موافقة',
      reject: 'رفض',
    },
  },
} as const;

// Get translation value
export function t(key: string, language: Language): string {
  const keys = key.split('.');
  let value: any = translations[language];
  
  for (const k of keys) {
    if (value && typeof value === 'object' && k in value) {
      value = value[k];
    } else {
      return key; // Return key if translation not found
    }
  }
  
  return typeof value === 'string' ? value : key;
}

// Get current language from localStorage
export function getCurrentLanguage(): Language {
  if (typeof window === 'undefined') return 'en';
  const stored = localStorage.getItem('language');
  return (stored === 'ar' || stored === 'en') ? stored : 'en';
}

// Set language in localStorage and update document
export function setLanguage(language: Language) {
  localStorage.setItem('language', language);
  document.documentElement.lang = language;
  document.documentElement.dir = LANGUAGES[language].dir;
}

// Initialize language on app load
export function initializeLanguage() {
  const language = getCurrentLanguage();
  setLanguage(language);
  return language;
}
