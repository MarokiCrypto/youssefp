import { useLanguage } from '@/hooks/useLanguage';
import { useState } from 'react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

interface OrderFormProps {
  services: Array<{ id: number; nameEn: string; nameAr: string }>;
}

/**
 * Order Form Component
 * Collects order details and sends via WhatsApp
 */
export function OrderForm({ services }: OrderFormProps) {
  const { t, language } = useLanguage();
  const [isLoading, setIsLoading] = useState(false);
  const [formData, setFormData] = useState({
    serviceId: '',
    platform: '',
    amount: '',
    currency: 'USD',
    accountId: '',
    customerName: '',
    phoneNumber: '',
    notes: '',
  });

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name: string, value: string) => {
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const validateForm = () => {
    if (!formData.serviceId) {
      toast.error(t('form.required'));
      return false;
    }
    if (!formData.platform) {
      toast.error(t('form.required'));
      return false;
    }
    if (!formData.amount) {
      toast.error(t('form.required'));
      return false;
    }
    if (!formData.accountId) {
      toast.error(t('form.required'));
      return false;
    }
    if (!formData.customerName) {
      toast.error(t('form.required'));
      return false;
    }
    if (!formData.phoneNumber) {
      toast.error(t('form.required'));
      return false;
    }
    if (!/^\+?[1-9]\d{1,14}$/.test(formData.phoneNumber.replace(/\D/g, ''))) {
      toast.error(t('form.invalidPhone'));
      return false;
    }
    return true;
  };

  const formatWhatsAppMessage = () => {
    const selectedService = services.find(
      (s) => s.id.toString() === formData.serviceId
    );
    const serviceName = language === 'en' ? selectedService?.nameEn : selectedService?.nameAr;

    const message = `
*${language === 'en' ? 'New Order' : 'طلب جديد'}*

${language === 'en' ? 'Service' : 'الخدمة'}: ${serviceName}
${language === 'en' ? 'Platform' : 'المنصة'}: ${formData.platform}
${language === 'en' ? 'Amount' : 'المبلغ'}: ${formData.amount} ${formData.currency}
${language === 'en' ? 'Account ID' : 'معرف الحساب'}: ${formData.accountId}
${language === 'en' ? 'Customer Name' : 'اسم العميل'}: ${formData.customerName}
${language === 'en' ? 'Phone' : 'الهاتف'}: ${formData.phoneNumber}
${formData.notes ? `${language === 'en' ? 'Notes' : 'ملاحظات'}: ${formData.notes}` : ''}
    `.trim();

    return encodeURIComponent(message);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    setIsLoading(true);

    try {
      // Format WhatsApp message
      const message = formatWhatsAppMessage();
      const whatsappUrl = `https://wa.me/212684119141?text=${message}`;

      // Open WhatsApp
      window.open(whatsappUrl, '_blank');

      // Show success message
      toast.success(t('form.success'));

      // Reset form
      setFormData({
        serviceId: '',
        platform: '',
        amount: '',
        currency: 'USD',
        accountId: '',
        customerName: '',
        phoneNumber: '',
        notes: '',
      });
    } catch (error) {
      console.error('Error submitting order:', error);
      toast.error(t('form.error'));
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Service Selection */}
      <div className="space-y-2">
        <Label htmlFor="serviceId">{t('form.service')}</Label>
        <Select value={formData.serviceId} onValueChange={(value) => handleSelectChange('serviceId', value)}>
          <SelectTrigger id="serviceId">
            <SelectValue placeholder={t('form.service')} />
          </SelectTrigger>
          <SelectContent>
            {services.map((service) => (
              <SelectItem key={service.id} value={service.id.toString()}>
                {language === 'en' ? service.nameEn : service.nameAr}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Platform */}
      <div className="space-y-2">
        <Label htmlFor="platform">{t('form.platform')}</Label>
        <Input
          id="platform"
          name="platform"
          placeholder={t('form.platform')}
          value={formData.platform}
          onChange={handleChange}
          required
        />
      </div>

      {/* Amount and Currency */}
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="amount">{t('form.amount')}</Label>
          <Input
            id="amount"
            name="amount"
            type="number"
            placeholder="0.00"
            value={formData.amount}
            onChange={handleChange}
            required
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="currency">{t('form.currency')}</Label>
          <Select value={formData.currency} onValueChange={(value) => handleSelectChange('currency', value)}>
            <SelectTrigger id="currency">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="USD">USD</SelectItem>
              <SelectItem value="EUR">EUR</SelectItem>
              <SelectItem value="GBP">GBP</SelectItem>
              <SelectItem value="USDT">USDT</SelectItem>
              <SelectItem value="MAD">MAD</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Account ID */}
      <div className="space-y-2">
        <Label htmlFor="accountId">{t('form.accountId')}</Label>
        <Input
          id="accountId"
          name="accountId"
          placeholder={t('form.accountId')}
          value={formData.accountId}
          onChange={handleChange}
          required
        />
      </div>

      {/* Customer Name */}
      <div className="space-y-2">
        <Label htmlFor="customerName">{t('form.customerName')}</Label>
        <Input
          id="customerName"
          name="customerName"
          placeholder={t('form.customerName')}
          value={formData.customerName}
          onChange={handleChange}
          required
        />
      </div>

      {/* Phone Number */}
      <div className="space-y-2">
        <Label htmlFor="phoneNumber">{t('form.phoneNumber')}</Label>
        <Input
          id="phoneNumber"
          name="phoneNumber"
          type="tel"
          placeholder="+212684119141"
          value={formData.phoneNumber}
          onChange={handleChange}
          required
        />
      </div>

      {/* Notes */}
      <div className="space-y-2">
        <Label htmlFor="notes">{t('form.notes')}</Label>
        <Textarea
          id="notes"
          name="notes"
          placeholder={t('form.notes')}
          value={formData.notes}
          onChange={handleChange}
          rows={4}
        />
      </div>

      {/* Submit Button */}
      <Button
        type="submit"
        disabled={isLoading}
        className="w-full btn-primary"
      >
        {isLoading ? t('common.loading') : t('form.submit')}
      </Button>
    </form>
  );
}
