/**
 * SEO Head Component
 * Adds meta tags and structured data to pages
 */

interface SEOHeadProps {
  title?: string;
  description?: string;
  image?: string;
  url?: string;
  type?: 'website' | 'article' | 'business.business';
}

export function SEOHead({
  title = 'Premium Digital Services - Fast, Secure & Professional',
  description = 'Premium digital services platform offering USDT recharges, betting sites, games, and more.',
  image = 'https://premium-services.com/og-image.png',
  url = 'https://premium-services.com',
  type = 'website',
}: SEOHeadProps) {
  // Update document title
  if (typeof document !== 'undefined') {
    document.title = title;
  }

  // Add meta tags
  const updateMeta = (name: string, content: string) => {
    let element = document.querySelector(`meta[name="${name}"]`) as HTMLMetaElement;
    if (!element) {
      element = document.createElement('meta');
      element.setAttribute('name', name);
      document.head.appendChild(element);
    }
    element.setAttribute('content', content);
  };

  const updateOGMeta = (property: string, content: string) => {
    let element = document.querySelector(`meta[property="${property}"]`) as HTMLMetaElement;
    if (!element) {
      element = document.createElement('meta');
      element.setAttribute('property', property);
      document.head.appendChild(element);
    }
    element.setAttribute('content', content);
  };

  if (typeof document !== 'undefined') {
    updateMeta('description', description);
    updateMeta('keywords', 'digital services, USDT, recharge, betting, games, premium');
    
    updateOGMeta('og:title', title);
    updateOGMeta('og:description', description);
    updateOGMeta('og:image', image);
    updateOGMeta('og:url', url);
    updateOGMeta('og:type', type);
    
    updateMeta('twitter:card', 'summary_large_image');
    updateMeta('twitter:title', title);
    updateMeta('twitter:description', description);
    updateMeta('twitter:image', image);
  }

  // Add structured data
  const structuredData = {
    '@context': 'https://schema.org',
    '@type': 'Organization',
    'name': 'Premium Services',
    'url': 'https://premium-services.com',
    'logo': 'https://premium-services.com/logo.png',
    'description': description,
    'sameAs': [
      'https://www.facebook.com/premiumservices',
      'https://www.twitter.com/premiumservices',
      'https://www.instagram.com/premiumservices',
    ],
    'contactPoint': {
      '@type': 'ContactPoint',
      'contactType': 'Customer Service',
      'telephone': '+212684119141',
      'email': 'contact@premium.com',
    },
  };

  if (typeof document !== 'undefined') {
    let script = document.querySelector('script[type="application/ld+json"]') as HTMLScriptElement;
    if (!script) {
      script = document.createElement('script');
      script.setAttribute('type', 'application/ld+json');
      document.head.appendChild(script);
    }
    script.textContent = JSON.stringify(structuredData);
  }

  return null;
}
