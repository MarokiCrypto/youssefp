import { useLanguage } from '@/hooks/useLanguage';
import { useOffers } from '@/hooks/useServices';
import { Spinner } from '@/components/ui/spinner';

/**
 * Offers Section Component
 * Displays promotional offers and banners
 */
export function OffersSection() {
  const { t, language } = useLanguage();
  const { offers, isLoading } = useOffers();

  if (isLoading) {
    return (
      <section className="bg-card border-y border-border">
        <div className="container section-padding flex justify-center">
          <Spinner />
        </div>
      </section>
    );
  }

  if (!offers || offers.length === 0) {
    return null;
  }

  return (
    <section className="bg-card border-y border-border">
      <div className="container section-padding">
        <h2 className="text-3xl font-bold mb-12">{t('home.offers')}</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {offers.map((offer) => (
            <div key={offer.id} className="card-minimal">
              {offer.imageUrl && (
                <img
                  src={offer.imageUrl}
                  alt={language === 'en' ? offer.titleEn : offer.titleAr}
                  className="w-full h-40 object-cover rounded mb-4"
                />
              )}
              <h3 className="text-xl font-bold mb-2">
                {language === 'en' ? offer.titleEn : offer.titleAr}
              </h3>
              {offer.descriptionEn && (
                <p className="text-muted-foreground mb-4">
                  {language === 'en' ? offer.descriptionEn : offer.descriptionAr}
                </p>
              )}
              {offer.discount && (
                <div className="inline-block bg-foreground text-background px-4 py-2 rounded font-bold">
                  {offer.discount}% OFF
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
