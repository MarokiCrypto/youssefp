import { useLanguage } from '@/hooks/useLanguage';
import { useReviews } from '@/hooks/useServices';
import { Spinner } from '@/components/ui/spinner';
import { Star } from 'lucide-react';

/**
 * Reviews Section Component
 * Displays customer testimonials and reviews
 */
export function ReviewsSection() {
  const { t, language } = useLanguage();
  const { reviews, isLoading } = useReviews();

  if (isLoading) {
    return (
      <section className="container section-padding flex justify-center">
        <Spinner />
      </section>
    );
  }

  if (!reviews || reviews.length === 0) {
    return null;
  }

  return (
    <section className="container section-padding">
      <h2 className="text-3xl font-bold mb-12 text-center">{t('home.testimonials')}</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {reviews.map((review) => (
          <div key={review.id} className="card-minimal">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold">{review.customerName}</h3>
              <div className="flex gap-1">
                {[...Array(review.rating)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-foreground" />
                ))}
              </div>
            </div>
            {review.imageUrl && (
              <img
                src={review.imageUrl}
                alt={review.customerName}
                className="w-full h-32 object-cover rounded mb-4"
              />
            )}
            <p className="text-muted-foreground">
              {language === 'en' ? review.commentEn : review.commentAr}
            </p>
          </div>
        ))}
      </div>
    </section>
  );
}
