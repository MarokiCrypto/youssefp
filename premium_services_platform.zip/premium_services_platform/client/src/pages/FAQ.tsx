import { useLanguage } from '@/hooks/useLanguage';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { useState } from 'react';
import { ChevronDown } from 'lucide-react';

export default function FAQ() {
  const { t } = useLanguage();
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  const faqs = [
    {
      q: 'How long does it take to process an order?',
      a: 'Most orders are processed within 5-15 minutes after submission.',
    },
    {
      q: 'What payment methods do you accept?',
      a: 'We accept various payment methods. Contact us for more details.',
    },
    {
      q: 'Is my information secure?',
      a: 'Yes, we use industry-standard encryption to protect your data.',
    },
    {
      q: 'Can I cancel my order?',
      a: 'Orders can be cancelled within 5 minutes of submission.',
    },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground">
      <Header />
      <main className="flex-1">
        <section className="container section-padding">
          <h1 className="text-4xl font-bold mb-4">{t('faq.title')}</h1>
          <p className="text-lg text-muted-foreground mb-12">{t('faq.description')}</p>

          <div className="max-w-3xl space-y-4">
            {faqs.map((faq, index) => (
              <div key={index} className="border border-border rounded overflow-hidden">
                <button
                  onClick={() => setOpenIndex(openIndex === index ? null : index)}
                  className="w-full p-6 flex items-center justify-between hover:bg-muted transition-colors text-left"
                >
                  <span className="font-semibold">{faq.q}</span>
                  <ChevronDown
                    className={`w-5 h-5 transition-transform ${
                      openIndex === index ? 'rotate-180' : ''
                    }`}
                  />
                </button>
                {openIndex === index && (
                  <div className="px-6 py-4 bg-muted border-t border-border">
                    <p className="text-muted-foreground">{faq.a}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
