import { useLanguage } from '@/hooks/useLanguage';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Plus, Edit2, Trash2 } from 'lucide-react';
import { toast } from 'sonner';

/**
 * Admin Dashboard
 * Manage services, offers, and reviews
 */
export default function AdminDashboard() {
  const { t } = useLanguage();
  const [activeTab, setActiveTab] = useState('services');

  // Services State
  const [services, setServices] = useState([
    { id: 1, nameEn: 'USDT Recharge', nameAr: 'شحن USDT', isActive: true },
    { id: 2, nameEn: 'Betting Sites', nameAr: 'مواقع المراهنات', isActive: true },
  ]);
  const [newService, setNewService] = useState({ nameEn: '', nameAr: '' });

  // Offers State
  const [offers, setOffers] = useState([
    { id: 1, titleEn: 'Summer Sale', titleAr: 'عرض الصيف', discount: 20, isActive: true },
  ]);
  const [newOffer, setNewOffer] = useState({ titleEn: '', titleAr: '', discount: 0 });

  // Reviews State
  const [reviews, setReviews] = useState([
    { id: 1, customerName: 'Ahmed', rating: 5, commentEn: 'Great service!', isApproved: false },
  ]);

  // Service Management
  const handleAddService = () => {
    if (!newService.nameEn || !newService.nameAr) {
      toast.error(t('form.required'));
      return;
    }
    setServices([
      ...services,
      { id: Date.now(), ...newService, isActive: true },
    ]);
    setNewService({ nameEn: '', nameAr: '' });
    toast.success('Service added successfully!');
  };

  const handleDeleteService = (id: number) => {
    setServices(services.filter((s) => s.id !== id));
    toast.success('Service deleted!');
  };

  // Offer Management
  const handleAddOffer = () => {
    if (!newOffer.titleEn || !newOffer.titleAr) {
      toast.error(t('form.required'));
      return;
    }
    setOffers([
      ...offers,
      { id: Date.now(), ...newOffer, isActive: true },
    ]);
    setNewOffer({ titleEn: '', titleAr: '', discount: 0 });
    toast.success('Offer added successfully!');
  };

  const handleDeleteOffer = (id: number) => {
    setOffers(offers.filter((o) => o.id !== id));
    toast.success('Offer deleted!');
  };

  // Review Management
  const handleApproveReview = (id: number) => {
    setReviews(
      reviews.map((r) =>
        r.id === id ? { ...r, isApproved: true } : r
      )
    );
    toast.success('Review approved!');
  };

  const handleDeleteReview = (id: number) => {
    setReviews(reviews.filter((r) => r.id !== id));
    toast.success('Review deleted!');
  };

  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground">
      <Header />

      <main className="flex-1">
        <section className="container section-padding">
          <h1 className="text-4xl font-bold mb-8">{t('admin.title')}</h1>

          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="services">{t('admin.services')}</TabsTrigger>
              <TabsTrigger value="offers">{t('admin.offers')}</TabsTrigger>
              <TabsTrigger value="reviews">{t('admin.reviews')}</TabsTrigger>
            </TabsList>

            {/* Services Tab */}
            <TabsContent value="services" className="space-y-6">
              <div className="card-minimal">
                <h2 className="text-2xl font-bold mb-6">{t('admin.addService')}</h2>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Service Name (English)</Label>
                      <Input
                        placeholder="Service name in English"
                        value={newService.nameEn}
                        onChange={(e) =>
                          setNewService({ ...newService, nameEn: e.target.value })
                        }
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Service Name (Arabic)</Label>
                      <Input
                        placeholder="اسم الخدمة بالعربية"
                        value={newService.nameAr}
                        onChange={(e) =>
                          setNewService({ ...newService, nameAr: e.target.value })
                        }
                      />
                    </div>
                  </div>
                  <Button onClick={handleAddService} className="btn-primary w-full">
                    <Plus className="w-4 h-4 mr-2" />
                    {t('admin.addService')}
                  </Button>
                </div>
              </div>

              <div className="space-y-4">
                {services.map((service) => (
                  <div key={service.id} className="card-minimal flex items-center justify-between">
                    <div>
                      <h3 className="font-semibold">{service.nameEn}</h3>
                      <p className="text-sm text-muted-foreground">{service.nameAr}</p>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm">
                        <Edit2 className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleDeleteService(service.id)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>

            {/* Offers Tab */}
            <TabsContent value="offers" className="space-y-6">
              <div className="card-minimal">
                <h2 className="text-2xl font-bold mb-6">{t('admin.addOffer')}</h2>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Offer Title (English)</Label>
                      <Input
                        placeholder="Offer title in English"
                        value={newOffer.titleEn}
                        onChange={(e) =>
                          setNewOffer({ ...newOffer, titleEn: e.target.value })
                        }
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Offer Title (Arabic)</Label>
                      <Input
                        placeholder="عنوان العرض بالعربية"
                        value={newOffer.titleAr}
                        onChange={(e) =>
                          setNewOffer({ ...newOffer, titleAr: e.target.value })
                        }
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Discount (%)</Label>
                    <Input
                      type="number"
                      placeholder="20"
                      value={newOffer.discount}
                      onChange={(e) =>
                        setNewOffer({ ...newOffer, discount: parseInt(e.target.value) })
                      }
                    />
                  </div>
                  <Button onClick={handleAddOffer} className="btn-primary w-full">
                    <Plus className="w-4 h-4 mr-2" />
                    {t('admin.addOffer')}
                  </Button>
                </div>
              </div>

              <div className="space-y-4">
                {offers.map((offer) => (
                  <div key={offer.id} className="card-minimal flex items-center justify-between">
                    <div>
                      <h3 className="font-semibold">{offer.titleEn}</h3>
                      <p className="text-sm text-muted-foreground">
                        {offer.discount}% discount
                      </p>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm">
                        <Edit2 className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleDeleteOffer(offer.id)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>

            {/* Reviews Tab */}
            <TabsContent value="reviews" className="space-y-6">
              <div className="space-y-4">
                {reviews.map((review) => (
                  <div key={review.id} className="card-minimal">
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <h3 className="font-semibold">{review.customerName}</h3>
                        <p className="text-sm text-muted-foreground">
                          Rating: {'⭐'.repeat(review.rating)}
                        </p>
                      </div>
                      <div className="flex gap-2">
                        {!review.isApproved && (
                          <Button
                            onClick={() => handleApproveReview(review.id)}
                            className="btn-primary text-sm"
                          >
                            {t('admin.approve')}
                          </Button>
                        )}
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleDeleteReview(review.id)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                    <p className="text-muted-foreground">{review.commentEn}</p>
                    {review.isApproved && (
                      <p className="text-sm text-green-600 mt-2">✓ Approved</p>
                    )}
                  </div>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </section>
      </main>

      <Footer />
    </div>
  );
}
