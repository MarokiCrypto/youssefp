import { useLanguage } from '@/hooks/useLanguage';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';

export default function Terms() {
  const { t } = useLanguage();

  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground">
      <Header />
      <main className="flex-1">
        <section className="container section-padding">
          <h1 className="text-4xl font-bold mb-8">{t('nav.terms')}</h1>
          <div className="max-w-3xl space-y-6 prose prose-invert">
            <h2 className="text-2xl font-bold">Terms & Conditions</h2>
            <p>
              These terms and conditions govern your use of our services. By using our platform, you agree to comply with these terms.
            </p>

            <h3 className="text-xl font-semibold">1. Service Description</h3>
            <p>
              We provide digital services including but not limited to USDT recharges, betting site services, and game services.
            </p>

            <h3 className="text-xl font-semibold">2. User Responsibilities</h3>
            <p>
              Users are responsible for providing accurate information and maintaining the confidentiality of their accounts.
            </p>

            <h3 className="text-xl font-semibold">3. Limitation of Liability</h3>
            <p>
              We are not liable for any indirect, incidental, special, or consequential damages arising from your use of our services.
            </p>

            <h3 className="text-xl font-semibold">4. Changes to Terms</h3>
            <p>
              We reserve the right to modify these terms at any time. Your continued use of our services constitutes acceptance of the updated terms.
            </p>

            <h3 className="text-xl font-semibold">5. Contact</h3>
            <p>
              For questions about these terms, please contact us at contact@premium.com or +212 684 119 141.
            </p>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
