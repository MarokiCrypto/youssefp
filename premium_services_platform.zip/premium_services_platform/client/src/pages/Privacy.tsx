import { useLanguage } from '@/hooks/useLanguage';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';

export default function Privacy() {
  const { t } = useLanguage();

  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground">
      <Header />
      <main className="flex-1">
        <section className="container section-padding">
          <h1 className="text-4xl font-bold mb-8">{t('nav.privacy')}</h1>
          <div className="max-w-3xl space-y-6">
            <h2 className="text-2xl font-bold">Privacy Policy</h2>
            <p>
              We are committed to protecting your privacy. This policy explains how we collect, use, and protect your personal information.
            </p>

            <h3 className="text-xl font-semibold">1. Information We Collect</h3>
            <p>
              We collect information you provide directly to us, including your name, email, phone number, and account details.
            </p>

            <h3 className="text-xl font-semibold">2. How We Use Your Information</h3>
            <p>
              We use your information to provide and improve our services, communicate with you, and comply with legal obligations.
            </p>

            <h3 className="text-xl font-semibold">3. Data Security</h3>
            <p>
              We implement industry-standard security measures to protect your data from unauthorized access and disclosure.
            </p>

            <h3 className="text-xl font-semibold">4. Third-Party Sharing</h3>
            <p>
              We do not sell or share your personal information with third parties without your consent, except as required by law.
            </p>

            <h3 className="text-xl font-semibold">5. Your Rights</h3>
            <p>
              You have the right to access, modify, or delete your personal information. Contact us for assistance.
            </p>

            <h3 className="text-xl font-semibold">6. Contact Us</h3>
            <p>
              For privacy concerns, please contact us at contact@premium.com or +212 684 119 141.
            </p>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
