import { useLanguage } from '@/hooks/useLanguage';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';

export default function About() {
  const { t } = useLanguage();

  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground">
      <Header />
      <main className="flex-1">
        <section className="container section-padding">
          <h1 className="text-4xl font-bold mb-8">{t('about.title')}</h1>
          <div className="max-w-3xl space-y-6">
            <p className="text-lg text-muted-foreground">
              {t('about.description')}
            </p>
            <p className="text-lg">
              We are a leading provider of digital services with years of experience in the industry. Our team is dedicated to providing the best service to our customers.
            </p>
            <p className="text-lg">
              Our mission is to make digital services accessible, secure, and reliable for everyone.
            </p>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
