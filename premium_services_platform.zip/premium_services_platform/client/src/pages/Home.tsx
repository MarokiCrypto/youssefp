import { useLanguage } from '@/hooks/useLanguage';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { OffersSection } from '@/components/OffersSection';
import { ReviewsSection } from '@/components/ReviewsSection';
import { ArrowRight, Zap, Shield, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'wouter';

/**
 * Home Page
 * Landing page with hero section, featured services, offers, and testimonials
 */
export default function Home() {
  const { t, isRTL } = useLanguage();

  const features = [
    {
      icon: Zap,
      title: 'Fast',
      desc: 'Instant processing',
    },
    {
      icon: Shield,
      title: 'Secure',
      desc: 'Protected transactions',
    },
    {
      icon: Clock,
      title: '24/7',
      desc: 'Always available',
    },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground">
      <Header />

      {/* Hero Section */}
      <section className="container section-padding flex flex-col md:flex-row items-center gap-12">
        <div className="flex-1 space-y-6">
          <h1 className="text-5xl md:text-6xl font-bold leading-tight">
            {t('home.title')}
          </h1>
          <p className="text-xl text-muted-foreground">
            {t('home.subtitle')}
          </p>
          <p className="text-lg text-foreground/80">
            {t('home.hero')}
          </p>
          <div className="flex gap-4 pt-4">
            <Link href="/services">
              <Button className="btn-primary flex items-center gap-2">
                {t('home.cta')}
                <ArrowRight className="w-4 h-4" />
              </Button>
            </Link>
            <Link href="/contact">
              <Button className="btn-secondary">
                {t('nav.contact')}
              </Button>
            </Link>
          </div>
        </div>

        {/* Hero Visual */}
        <div className="flex-1">
          <div className="aspect-square bg-muted rounded-lg border border-border flex items-center justify-center">
            <div className="text-center space-y-4">
              <div className="w-24 h-24 bg-foreground rounded-lg mx-auto flex items-center justify-center">
                <span className="text-4xl text-background font-bold">P</span>
              </div>
              <p className="text-muted-foreground">{t('home.hero')}</p>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="bg-card border-y border-border">
        <div className="container section-padding">
          <h2 className="text-3xl font-bold text-center mb-12">
            Why Choose Us
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <div key={index} className="card-minimal text-center">
                  <Icon className="w-12 h-12 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                  <p className="text-muted-foreground">{feature.desc}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Services Preview Section */}
      <section className="container section-padding">
        <h2 className="text-3xl font-bold mb-12">{t('home.featuredServices')}</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            { title: 'USDT Recharge', icon: '💰' },
            { title: 'Betting Sites', icon: '🎲' },
            { title: 'Games', icon: '🎮' },
            { title: 'Other Services', icon: '⚙️' },
          ].map((service, index) => (
            <div key={index} className="card-minimal flex flex-col items-center text-center">
              <div className="text-4xl mb-4">{service.icon}</div>
              <h3 className="text-lg font-semibold">{service.title}</h3>
              <p className="text-sm text-muted-foreground mt-2">
                Professional service
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* Offers Section */}
      <OffersSection />

      {/* Reviews Section */}
      <ReviewsSection />

      {/* CTA Section */}
      <section className="bg-foreground text-background">
        <div className="container section-padding text-center space-y-6">
          <h2 className="text-4xl font-bold">{t('home.cta')}</h2>
          <p className="text-lg opacity-90 max-w-2xl mx-auto">
            {t('home.hero')}
          </p>
          <Link href="/services">
            <Button className="bg-background text-foreground hover:bg-muted">
              {t('home.cta')}
            </Button>
          </Link>
        </div>
      </section>

      <Footer />
    </div>
  );
}
