import { useLanguage } from '@/hooks/useLanguage';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { OrderForm } from '@/components/OrderForm';
import { useServices } from '@/hooks/useServices';
import { Spinner } from '@/components/ui/spinner';

/**
 * Services Page
 * Displays available services and order form
 */
export default function Services() {
  const { t } = useLanguage();
  const { services, isLoading } = useServices();

  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground">
      <Header />

      <main className="flex-1">
        {/* Page Header */}
        <section className="bg-card border-b border-border">
          <div className="container section-padding">
            <h1 className="text-4xl font-bold mb-4">{t('services.title')}</h1>
            <p className="text-lg text-muted-foreground">
              {t('services.description')}
            </p>
          </div>
        </section>

        {/* Services and Order Form */}
        <section className="container section-padding">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            {/* Services List */}
            <div className="lg:col-span-1">
              <h2 className="text-2xl font-bold mb-6">{t('services.selectService')}</h2>
              {isLoading ? (
                <div className="flex justify-center py-8">
                  <Spinner />
                </div>
              ) : services.length > 0 ? (
                <div className="space-y-3">
                  {services.map((service) => (
                    <div
                      key={service.id}
                      className="p-4 border border-border rounded hover:bg-muted transition-colors cursor-pointer"
                    >
                      <h3 className="font-semibold">{service.nameEn}</h3>
                      <p className="text-sm text-muted-foreground">{service.nameAr}</p>
                      {service.descriptionEn && (
                        <p className="text-xs text-muted-foreground mt-2">{service.descriptionEn}</p>
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-muted-foreground">{t('common.loading')}</p>
              )}
            </div>

            {/* Order Form */}
            <div className="lg:col-span-2">
              <div className="card-minimal">
                <h2 className="text-2xl font-bold mb-6">{t('form.title')}</h2>
                <OrderForm services={services} />
              </div>
            </div>
          </div>
        </section>

        {/* How It Works */}
        <section className="bg-card border-y border-border">
          <div className="container section-padding">
            <h2 className="text-3xl font-bold text-center mb-12">How It Works</h2>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              {[
                { step: 1, title: 'Select Service', desc: 'Choose from our services' },
                { step: 2, title: 'Fill Form', desc: 'Enter your details' },
                { step: 3, title: 'Send Order', desc: 'Submit via WhatsApp' },
                { step: 4, title: 'Receive', desc: 'Get your service' },
              ].map((item) => (
                <div key={item.step} className="text-center">
                  <div className="w-12 h-12 bg-foreground text-background rounded-full flex items-center justify-center font-bold text-lg mx-auto mb-4">
                    {item.step}
                  </div>
                  <h3 className="font-semibold mb-2">{item.title}</h3>
                  <p className="text-sm text-muted-foreground">{item.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
